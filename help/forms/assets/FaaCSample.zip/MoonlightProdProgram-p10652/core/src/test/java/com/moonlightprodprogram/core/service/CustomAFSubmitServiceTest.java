package com.moonlightprodprogram.core.service;


import com.adobe.aemds.guide.model.FormSubmitInfo;
import com.adobe.aemds.guide.service.FormSubmitActionService;
import com.adobe.aemds.guide.utils.GuideConstants;
import com.adobe.forms.common.service.ContentType;
import com.adobe.forms.common.service.FileAttachmentWrapper;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.testing.mock.sling.servlet.MockRequestPathInfo;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import uk.org.lidalia.slf4jtest.TestLogger;
import uk.org.lidalia.slf4jtest.TestLoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(AemContextExtension.class)
public class CustomAFSubmitServiceTest {
    private static final String GUIDE_PATH = "/content/forms/af/smtp-example";
    private final String EMPTY_DATA_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><afData><afUnboundData><data><firstName>XYZ</firstName></data></afUnboundData><afBoundData></afBoundData></afData>";

    private TestLogger logger = TestLoggerFactory.getTestLogger(CustomAFSubmitServiceTest.class);
    private DataManager dataManager;

    @BeforeEach
    public void setup(AemContext context) throws Exception {
        dataManager = mockDataManager();
        context.registerService(DataManager.class, dataManager);


        CustomAFSubmitService fixture = new CustomAFSubmitService();
        Map<String, Object> props = new HashMap<>(2);
        props.put("component.name", FormSubmitActionService.class.getName());
        context.registerInjectActivateService(fixture, props);
    }

    private static DataManager mockDataManager() {
        DataManager dataManager = mock(DataManager.class);
        when(dataManager.put(any(), any())).thenReturn(any());
        return dataManager;
    }


    @Test
    void submitTest(AemContext context) throws IOException, ServletException, JSONException {
        MockSlingHttpServletRequest request = context.request();
        MockSlingHttpServletResponse response = context.response();

        FormSubmitInfo formSubmitInfo = new FormSubmitInfo();
        formSubmitInfo.setFormContainerPath(GUIDE_PATH + "/jcr:content/guideContainer");
        formSubmitInfo.setData(EMPTY_DATA_XML);
        formSubmitInfo.setContentType(ContentType.XML.toString());
        org.json.JSONObject fileMapObject = new JSONObject();
        fileMapObject.put("guide[0].panel[0].file[0]", "fileupload/abc.jpg");
        formSubmitInfo.setFileAttachmentMap(fileMapObject.toString());

        List<FileAttachmentWrapper> fileAttachmentWrappers = new ArrayList<>();
        FileAttachmentWrapper wrapper = new FileAttachmentWrapper("fileupload/abc.jpg", "image/jpeg", new byte[0]);
        fileAttachmentWrappers.add(wrapper);
        formSubmitInfo.setFileAttachments(fileAttachmentWrappers);

        MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) request.getRequestPathInfo();
        requestPathInfo.setResourcePath("/content/test");
        requestPathInfo.setSelectorString("selectors");

        FormSubmitActionService service = context.getService(FormSubmitActionService.class);
        CustomAFSubmitService fixture = (CustomAFSubmitService) service;

        Map<String, Object> result =  fixture.submit(formSubmitInfo);
        assertNotNull(result);
    }

}
