package com.moonlightprodprogram.core.service;


import com.adobe.forms.common.service.ContentType;
import com.adobe.forms.common.service.DataOptions;
import com.adobe.forms.common.service.DataProvider;
import com.adobe.forms.common.service.PrefillData;
import com.day.cq.wcm.api.Page;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.testing.mock.sling.servlet.MockRequestPathInfo;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletResponse;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import uk.org.lidalia.slf4jtest.TestLogger;
import uk.org.lidalia.slf4jtest.TestLoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(AemContextExtension.class)
public class CustomAFPrefillServiceTest {

    private TestLogger logger = TestLoggerFactory.getTestLogger(CustomAFPrefillServiceTest.class);
    private DataManager dataManager;

    private Page formPage;
    private Resource formContainerResource;

    @BeforeEach
    public void setup(AemContext context) throws Exception {

        // prepare a page with a test resource
        formPage = context.create().page("/content/forms/af/abc");
        formContainerResource = context.create().resource(formPage, "guideContainer",
                "sling:resourceType", "fd/af/components/guideContainer");
        dataManager = mockDataManager();
        context.registerService(DataManager.class, dataManager);


        CustomAFPrefillService fixture = new CustomAFPrefillService();
        Map<String, Object> props = new HashMap<>(2);
        props.put("component.name", DataProvider.class.getName());
        context.registerInjectActivateService(fixture, props);
    }

    private static DataManager mockDataManager() {
        DataManager dataManager = mock(DataManager.class);
        when(dataManager.get(any())).thenReturn(any());
        return dataManager;
    }

    @Test
    void getPrefillDataTest(AemContext context) throws IOException, ServletException {
        MockSlingHttpServletRequest request = context.request();
        MockSlingHttpServletResponse response = context.response();

        DataOptions dataOptions = new DataOptions();
        dataOptions.setContentType(ContentType.JSON);
        dataOptions.setAemFormContainer(formContainerResource);
        dataOptions.setFormResource(formPage.getContentResource());
        Map<String, Object> extras = new HashMap<>();
        extras.put(DataManager.UNIQUE_ID, "12917221212");
        dataOptions.setExtras(extras);

        MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) request.getRequestPathInfo();
        requestPathInfo.setResourcePath("/content/test");
        requestPathInfo.setSelectorString("selectors");

        DataProvider service = context.getService(DataProvider.class);
        CustomAFPrefillService fixture = (CustomAFPrefillService) service;

        PrefillData prefillData =  fixture.getPrefillData(dataOptions);
        assertNull(prefillData);
        //assertTrue(prefillData.getContentType() == ContentType.JSON);
    }
}
