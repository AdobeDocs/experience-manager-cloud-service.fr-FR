/*
 *  Copyright 2020 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.moonlightprodprogram.it.tests;

import com.adobe.forms.common.service.ContentType;
import com.adobe.forms.common.service.DataOptions;
import com.adobe.forms.common.service.PrefillData;
import com.moonlightprodprogram.core.service.CustomAFPrefillService;
import com.moonlightprodprogram.core.service.DataManager;
import org.apache.commons.io.IOUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.junit.annotations.SlingAnnotationsTestRunner;
import org.apache.sling.junit.annotations.TestReference;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *  Test case which uses OSGi services injection
 *
 *  <p>It relies on the <tt>ResourceResolverFactory</tt> to create test resources
 *  and then adapt them to the class under test - <tt>HelloWorldModel</tt>.</p>
 */
@RunWith(SlingAnnotationsTestRunner.class)
// ignore possible null pointer exceptions, deprecation warnings, loginAdmin usage, and generic exceptions
@SuppressWarnings({"squid:S2259", "squid:CallToDeprecatedMethod", "AEM Rules:AEM-11", "squid:S00112"})
public class CustomPrefillServiceServerSideTest {

    private final static String FORM_ROOT_PATH = "/content/forms/af";
    private final static String FORM_PAGE_NAME = "testform";
    private final static String FORM_PAGE_PATH = FORM_ROOT_PATH + "/" + FORM_PAGE_NAME;
    private final static String DATA_ID = UUID.randomUUID().toString();
    private final String EMPTY_DATA_JSON = "{\"afData\" : {\"afUnboundData\" : {\"data\": {\"firstName\" : \"XYZ\"}},\"afBoundData\" : {}}}";

    @TestReference
    private ResourceResolverFactory rrf;

    @TestReference
    private CustomAFPrefillService customPrefill;

    @TestReference
    private DataManager dataManager;


    @Before
    public void prepareData() throws Exception {
        new AdminResolverCallable() {
            @Override
            protected void call0(ResourceResolver rr) throws Exception {
                Map<String, Object> pageProperties = new HashMap<>();
                pageProperties.put("jcr:primaryType", "cq:Page");
                rr.create(rr.getResource(FORM_ROOT_PATH), FORM_PAGE_NAME, pageProperties);
            }
        }.call();
    }

    @After
    public void cleanupData() throws Exception {
        new AdminResolverCallable() {
            @Override
            protected void call0(ResourceResolver rr) throws Exception {
                Resource testResource = rr.getResource(FORM_PAGE_PATH);
                if ( testResource != null ) {
                    rr.delete(testResource);
                }
            }
        }.call();
    }

    @Test
    public void testCustomPrefillServiceData() throws Exception {

        assertNotNull("Expecting the Resource Resolver Factory to be injected by Sling test runner", rrf);
        assertNotNull("Expecting the Custom Prefill Service to be injected by Sling test runner", customPrefill);
        assertNotNull("Expecting the DataManager to be injected by Sling test runner", dataManager);

        new AdminResolverCallable() {
            @Override
            protected void call0(ResourceResolver rr) throws Exception {
                // create data options
                Resource formPageResource = rr.getResource(FORM_PAGE_PATH);
                DataOptions dataOptions = new DataOptions();
                dataOptions.setContentType(ContentType.JSON);
                dataOptions.setFormResource(formPageResource);
                Map<String, Object> extras = new HashMap<>();
                extras.put(DataManager.UNIQUE_ID, DATA_ID);
                dataOptions.setExtras(extras);

                // initialize the data manager with this data
                dataManager.put(DATA_ID, EMPTY_DATA_JSON);

                // invoke the prefill service
                PrefillData data = customPrefill.getPrefillData(dataOptions);
                String dataString = IOUtils.toString(data.getInputStream(), Charset.defaultCharset());
                assertNotNull("Expecting Custom Prefill Service to return non-null data", data);
                assertEquals("Expecting Custom Prefill Service to return correct data", dataString, EMPTY_DATA_JSON);

            }
        }.call();
    }


    private abstract class AdminResolverCallable implements Callable<Void> {

        @Override
        public Void call() throws Exception {

            if ( rrf == null ) {
                throw new IllegalStateException("ResourceResolverFactory not injected");
            }

            @SuppressWarnings("deprecation") // fine for testing
                    ResourceResolver rr = rrf.getAdministrativeResourceResolver(null);
            try {
                call0(rr);
                rr.commit();
            } finally {
                if ( rr != null ) {
                    rr.close();
                }
            }
            return null;
        }

        protected abstract void call0(ResourceResolver rr) throws Exception;

    }
}
