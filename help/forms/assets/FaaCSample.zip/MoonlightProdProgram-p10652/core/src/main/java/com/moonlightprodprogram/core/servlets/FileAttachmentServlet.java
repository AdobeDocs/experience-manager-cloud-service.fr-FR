package com.moonlightprodprogram.core.servlets;

import com.adobe.forms.common.service.FileAttachmentWrapper;
import com.moonlightprodprogram.core.service.DataManager;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.propertytypes.ServiceDescription;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Servlet that writes some sample content into the response. It is mounted for
 * all resources of a specific Sling resource type. The
 * {@link SlingSafeMethodsServlet} shall be used for HTTP methods that are
 * idempotent. For write operations use the {@link SlingAllMethodsServlet}.
 */
@Component(service = Servlet.class,
        property = {
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.resourceTypes=" + "fd/af/components/guideContainer",
                "sling.servlet.selectors=" + FileAttachmentServlet.SELECTOR
        })
@ServiceDescription("Adaptive Form File Attachment Retrieve Servlet")
public class FileAttachmentServlet extends SlingSafeMethodsServlet {

    public static final String SELECTOR = "file.get";
    private static final long serialVersionUID = 1L;

    @Reference
    DataManager dataManager;

    @Override
    protected void doGet(final SlingHttpServletRequest req,
                         final SlingHttpServletResponse resp) throws ServletException, IOException {
        final Resource resource = req.getResource();
        // /content/forms/af/abc/jcr:content/guideContainer.file.get/fileAttachmentUuid/fileName
        String suffix = req.getRequestPathInfo().getSuffix();
        byte[] responseObj = null;
        String[] suffixParts = StringUtils.split(suffix, "/");
        if (suffixParts != null && suffixParts.length > 1 && StringUtils.isNotBlank(suffixParts[0])) {
            String fileUuid = suffixParts[0];
            FileAttachmentWrapper attachment = (FileAttachmentWrapper) dataManager.get(fileUuid);
            String contentType = attachment.getContentType();
            responseObj = IOUtils.toByteArray(attachment.getInputStream());
            if (contentType != null && !contentType.trim().isEmpty()) {
                resp.setContentType(contentType);
            }
            OutputStream os;
            os = resp.getOutputStream();
            os.write(responseObj);
            os.close();
        }
    }
}